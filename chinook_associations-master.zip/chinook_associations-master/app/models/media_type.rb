class MediaType < ApplicationRecord
  has_many :tracks
end
