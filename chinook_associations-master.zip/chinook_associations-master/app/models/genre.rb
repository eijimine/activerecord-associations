class Genre < ApplicationRecord
  has_many :tracks
end
