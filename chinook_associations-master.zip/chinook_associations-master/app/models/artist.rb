class Artist < ApplicationRecord
  has_many :albums
end
